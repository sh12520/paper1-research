# RDINP GOAL-1 冻结复现包

从解压后的仓库根目录运行。包内的 Step 1 r02 是封存仿真数据，Step 2 是同主机真实环回协议实测，链路扰动由实验程序注入。
原始任务记录、聚合表、计划和协议源码保留各自的路径。试验私钥、进程配置和运行数据库在实测时生成。

## 核验与复算

用 Python 3.11 或更新版本执行下列命令。第一条逐项对照压缩包中的 SHA-256。第二条只对封存数据复算门禁。第三条执行一轮新的本机实测并沿用封存的 Step 1。新目录和新结果文件需选用未占用路径。

~~~bash
python -B rdinp/experiments/permit-prototype/freeze_bundle.py --verify <复现包.zip>
python -B rdinp/experiments/permit-prototype/gate.py --pairs rdinp/experiments/permit-prototype/evidence/step2-20261128-r01/pairs --matrix rdinp/experiments/permit-prototype/evidence/step2-20261128-r01/safety/safety.json --c2 rdinp/experiments/permit-prototype/evidence/step2-20261128-r01/c2/c2_cost.json --out <新结果.json>
python -B rdinp/experiments/permit-prototype/reproduce.py --assets <原图目录> --out <新目录>
~~~

新一轮实测自动用 rdinp/requirements.txt 创建隔离环境，需要可用的 Python 包源。也可传 --python 指定已装有锁定依赖的解释器。原图目录提供 astronaut.png、camera.png 和 coffee.png 三个 scikit-image 样图。文件摘要固定在 [标定数据](rdinp/experiments/structured-fast-slow/calibration.json)，传入的文件会逐个核验。实测时间随机器负载和平台变化，独立复算可以核验本报告的具体数字。

## 重新出图

绘图用 Matplotlib 3.10.3，并需要 Microsoft YaHei、Noto Sans SC、Noto Sans CJK SC 或 SimHei 中的一种字体。

~~~bash
python -m pip install matplotlib==3.10.3
python -B rdinp/experiments/permit-prototype/plot_paper.py --pairs rdinp/experiments/permit-prototype/evidence/step2-20261128-r01/pairs --c2 rdinp/experiments/permit-prototype/evidence/step2-20261128-r01/c2/c2_cost.json --out <图表目录>
~~~

生成的图表同时提供 600 DPI PNG 和矢量 PDF。Step 1 数据与归因表默认从包内的冻结目录读取。

## 中文论文

[Markdown 主稿](rdinp/experiments/permit-prototype/paper/RDINP_中文小论文初稿.md) · [Word 阅读版](rdinp/experiments/permit-prototype/paper/RDINP_中文小论文初稿.docx)

从包的根目录用 Pandoc 可重新导出 Word。

~~~bash
pandoc "rdinp/experiments/permit-prototype/paper/RDINP_中文小论文初稿.md" --resource-path="rdinp/experiments/permit-prototype/paper" -o "<新稿.docx>"
~~~
